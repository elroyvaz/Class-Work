var courses = ["CP102", "CP104", "CP164", "CP312", "CP202", "CP414", "CP321", "CP361", "CP112", "CP211"];

var randomCourseIndex = Math.floor(Math.random() * courses.length);
var randomCourse = courses[randomCourseIndex];

var outputMessage = "You are registered in the course: " + randomCourse;

document.getElementById("course").textContent = outputMessage;

