/* The following values are just for testing
The code will be tested by changing the marks of
quizzes, assignments, project, midterm, and final*/
var quizzes = [9, 9, 10, 10];
var assigns = [9, 10, 10, 10, 9];
var project = 8;
var midterm = 80;
var final = 70;
var marks = 14.23; // Initialize with an overall performance value out of 10

// Weightage for each assessment
var quizWeight = 0.3;
var assignmentWeight = 0.2;
var projectWeight = 0.1;
var midtermWeight = 0.2;
var finalWeight = 0.2;

// Calculate total marks out of 100
var totalMarks = calculateTotalMarks();

// Display the total marks on the webpage
document.getElementById("grade").textContent = "Final Marks: " + totalMarks.toFixed(1);

// Function to calculate total marks
function calculateTotalMarks() {
    var totalQuizMarks = marks * quizWeight * 10; // Multiply by 10 to get the final marks out of 100
    var totalAssignmentMarks = marks * assignmentWeight * 10;
    var totalProjectMarks = marks * projectWeight * 10;
    var totalMidtermMarks = (midterm / 100) * midtermWeight; // Corrected: Divide by 100 for midterm
    var totalFinalMarks = (final / 100) * finalWeight; // Corrected: Divide by 100 for final

    return (totalQuizMarks + totalAssignmentMarks + totalProjectMarks + totalMidtermMarks + totalFinalMarks);
}
